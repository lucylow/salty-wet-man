/* SafeScan Field Manual: local previews may be retried, but concurrent actions must never create ambiguous state. */
import { useEffect, useRef } from "react";

export type ActionGuard = {
  begin: () => boolean;
  release: () => void;
  isPending: () => boolean;
};

export function createActionGuard(): ActionGuard {
  let pending = false;
  return {
    begin: () => {
      if (pending) return false;
      pending = true;
      return true;
    },
    release: () => { pending = false; },
    isPending: () => pending,
  };
}

export function useActionGuard() {
  const guardRef = useRef<ActionGuard | null>(null);
  if (!guardRef.current) guardRef.current = createActionGuard();
  useEffect(() => () => guardRef.current?.release(), []);
  return guardRef.current;
}
