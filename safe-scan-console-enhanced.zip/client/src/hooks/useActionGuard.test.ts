/* SafeScan Field Manual: local actions must acquire once, release reliably, and remain isolated from other actions. */
import { describe, expect, it } from "vitest";
import { createActionGuard } from "./useActionGuard";

describe("SafeScan action guard", () => {
  it("prevents repeated starts until the active action is released", () => {
    const guard = createActionGuard();
    expect(guard.begin()).toBe(true);
    expect(guard.begin()).toBe(false);
    expect(guard.isPending()).toBe(true);
    guard.release();
    expect(guard.isPending()).toBe(false);
    expect(guard.begin()).toBe(true);
  });

  it("keeps independently guarded actions isolated", () => {
    const stream = createActionGuard();
    const scan = createActionGuard();
    expect(stream.begin()).toBe(true);
    expect(scan.begin()).toBe(true);
  });
});
