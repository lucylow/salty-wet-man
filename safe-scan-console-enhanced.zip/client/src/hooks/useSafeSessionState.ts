/* SafeScan Field Manual: durable local controls should restore safely and fail quietly when browser storage is unavailable. */
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { readStoredValue, writeStoredValue } from "@/lib/safeStorage";

export function useSafeSessionState<T>(key: string, fallback: T, validate: (value: unknown) => value is T): [T, Dispatch<SetStateAction<T>>] {
  const [value, setValue] = useState<T>(() => readStoredValue(key, fallback, validate));

  useEffect(() => {
    writeStoredValue(key, value);
  }, [key, value]);

  return [value, setValue];
}
