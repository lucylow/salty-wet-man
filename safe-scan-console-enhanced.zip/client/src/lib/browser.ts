/* SafeScan Field Manual: browser integrations are progressive enhancements with a deliberate recovery path. */
export async function copyTextWithFallback(text: string): Promise<boolean> {
  try {
    if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fall through to the legacy selection-based path for restricted clipboard contexts.
  }

  if (typeof document === "undefined") return false;
  let field: HTMLTextAreaElement | null = null;
  try {
    field = document.createElement("textarea");
    field.value = text;
    field.setAttribute("readonly", "");
    field.style.position = "fixed";
    field.style.opacity = "0";
    document.body.appendChild(field);
    field.select();
    return document.execCommand("copy");
  } catch {
    return false;
  } finally {
    field?.parentNode?.removeChild(field);
  }
}
