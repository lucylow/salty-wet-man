/* SafeScan Field Manual: clipboard access is an enhancement; its absence must leave a clear false result rather than throw. */
import { describe, expect, it } from "vitest";
import { copyTextWithFallback } from "./browser";

describe("SafeScan browser helpers", () => {
  it("fails safely when no usable clipboard or document is available", async () => {
    await expect(copyTextWithFallback("local fixture payload")).resolves.toBe(false);
  });
});
