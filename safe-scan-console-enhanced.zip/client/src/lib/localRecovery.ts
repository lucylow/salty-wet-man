/* SafeScan Field Manual: refreshes must resolve to an explicit local outcome, including the retained-data recovery path. */
import type { LocalStreamState } from "./mockData";

export type FixtureRefreshOutcome = {
  streamState: LocalStreamState;
  lastRefresh: string;
  message: string;
  tone: "success" | "warning";
};

export function getFixtureRefreshOutcome(revision: number, didFail: boolean): FixtureRefreshOutcome {
  const safeRevision = Number.isInteger(revision) && revision >= 1 ? revision : 1;
  if (didFail) {
    return {
      streamState: "degraded",
      lastRefresh: `Fallback retained · r${safeRevision}`,
      message: `Fixture r${safeRevision} was retained after a simulated refresh failure.`,
      tone: "warning",
    };
  }
  return {
    streamState: "ready",
    lastRefresh: `Fixture r${safeRevision} · refreshed`,
    message: `Local fixture r${safeRevision} is ready. No network request was made.`,
    tone: "success",
  };
}
