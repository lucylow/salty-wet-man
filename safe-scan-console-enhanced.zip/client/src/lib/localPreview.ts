/* SafeScan Field Manual: local previews must present explicit state, cause, and recovery language from one source of truth. */
import type { RequestValidation } from "./mockData";

export type LocalValidationState = "idle" | "valid" | "error";

export type ValidationOutcome = {
  heading: string;
  detail: string;
  tone: "neutral" | "success" | "warning";
  canSimulate: boolean;
};

export function getValidationOutcome(state: LocalValidationState, validation: RequestValidation): ValidationOutcome {
  if (state === "idle") {
    return { heading: "Validate before sending", detail: "The preview checks required fields locally and never transmits this fixture.", tone: "neutral", canSimulate: false };
  }
  if (validation.valid) {
    return { heading: validation.label, detail: validation.message, tone: "success", canSimulate: true };
  }
  return { heading: validation.label, detail: validation.message, tone: "warning", canSimulate: false };
}
