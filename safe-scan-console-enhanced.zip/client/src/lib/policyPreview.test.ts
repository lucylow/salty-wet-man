/* SafeScan Field Manual: policy adjustments must be normalized, recoverable, and incapable of changing a production policy. */
import { describe, expect, it } from "vitest";
import { editLocalPolicyThreshold, saveLocalPolicyPreview } from "./policyPreview";

describe("SafeScan local policy preview", () => {
  it("normalizes edits and clears stale save or approval state", () => {
    expect(editLocalPolicyThreshold(1.4, 0.72)).toEqual({ threshold: 0.95, saved: false, approvalRequested: false });
  });

  it("requires an actual local change before allowing a save", () => {
    const baseline = { threshold: 0.72, saved: false, approvalRequested: false };
    expect(saveLocalPolicyPreview(baseline, 0.72)).toMatchObject({ tone: "warning", state: baseline });
    expect(saveLocalPolicyPreview({ threshold: 0.8, saved: false, approvalRequested: true }, 0.72)).toMatchObject({ tone: "success", state: { threshold: 0.8, saved: true, approvalRequested: false } });
  });
});
