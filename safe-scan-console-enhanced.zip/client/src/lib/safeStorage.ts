/* SafeScan Field Manual: persisted local choices are optional, validated, and never allowed to block the console. */
export interface StringStorage {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
}

export function resolveSessionStorage(): StringStorage | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
}

export function readStoredValue<T>(key: string, fallback: T, validate: (value: unknown) => value is T, storage: StringStorage | null = resolveSessionStorage()): T {
  if (!storage) return fallback;
  try {
    const rawValue = storage.getItem(key);
    if (!rawValue) return fallback;
    const parsed: unknown = JSON.parse(rawValue);
    return validate(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

export function writeStoredValue(key: string, value: unknown, storage: StringStorage | null = resolveSessionStorage()): boolean {
  if (!storage) return false;
  try {
    storage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}
