/* SafeScan Field Manual: deterministic fixture data exposes source, freshness, and fallback status clearly. */
export type Verdict = "safe" | "review" | "blocked";
export type RequestMode = "multipart" | "base64";
export type ValidationFixture = "valid" | "unsupported" | "oversized" | "malformed";
export type ScanFixtureId = "profile-photo" | "editorial-illustration" | "ambiguous-crop";
export type LocalStreamState = "ready" | "refreshing" | "degraded" | "paused";
export const MIN_PASS_THRESHOLD = 0.4;
export const MAX_PASS_THRESHOLD = 0.95;
export const DEFAULT_PASS_THRESHOLD = 0.72;

export type ActivityEvent = {
  id: string;
  time: string;
  source: "avatar-service" | "community-api" | "profile-upload" | "marketplace" | "comment-media" | "partner-ingest";
  sourceLabel: string;
  verdict: Verdict;
  label: string;
  score: number;
  ageMinutes: number;
};

export type ClassificationResult = {
  verdict: Extract<Verdict, "safe" | "review">;
  title: string;
  detail: string;
  safeConfidence: number;
  categories: Array<{ label: string; score: number; emphasis?: "signal" | "caution" }>;
  latencyMs: number;
};

export type RequestValidation = {
  status: 200 | 413 | 415 | 422;
  label: string;
  message: string;
  valid: boolean;
  payload: string;
};

export type StreamStatePresentation = {
  label: string;
  tone: LocalStreamState;
  detail: string;
};

export type FixtureMetrics = {
  requests: number;
  passRate: number;
  reviewQueue: number;
};

export type FixtureFilters = {
  showAll: boolean;
  verdict: "all" | Verdict;
  source: "all" | ActivityEvent["source"];
  confidence: "all" | "high" | "review";
  timeRange: "30m" | "2h" | "24h";
};

const BASE_EVENTS: readonly ActivityEvent[] = [
  { id: "evt_0198", time: "14:32:08", source: "avatar-service", sourceLabel: "Avatar service", verdict: "safe", label: "neutral", score: 0.98, ageMinutes: 2 },
  { id: "evt_0197", time: "14:31:52", source: "community-api", sourceLabel: "Community API", verdict: "review", label: "sensitive", score: 0.64, ageMinutes: 3 },
  { id: "evt_0196", time: "14:31:44", source: "profile-upload", sourceLabel: "Profile upload", verdict: "blocked", label: "policy match", score: 0.93, ageMinutes: 3 },
  { id: "evt_0195", time: "14:31:17", source: "marketplace", sourceLabel: "Marketplace", verdict: "safe", label: "illustration", score: 0.87, ageMinutes: 4 },
  { id: "evt_0194", time: "14:30:58", source: "comment-media", sourceLabel: "Comment media", verdict: "review", label: "ambiguous crop", score: 0.58, ageMinutes: 5 },
  { id: "evt_0193", time: "14:30:21", source: "profile-upload", sourceLabel: "Profile upload", verdict: "safe", label: "neutral", score: 0.91, ageMinutes: 5 },
  { id: "evt_0192", time: "14:29:47", source: "partner-ingest", sourceLabel: "Partner ingest", verdict: "safe", label: "product photo", score: 0.79, ageMinutes: 6 },
  { id: "evt_0191", time: "14:29:08", source: "community-api", sourceLabel: "Community API", verdict: "blocked", label: "policy match", score: 0.89, ageMinutes: 7 },
];

export const scanFixtures: ReadonlyArray<{ id: ScanFixtureId; label: string; description: string }> = [
  { id: "profile-photo", label: "Profile photo", description: "Clear neutral sample" },
  { id: "editorial-illustration", label: "Editorial illustration", description: "High-confidence safe sample" },
  { id: "ambiguous-crop", label: "Ambiguous crop", description: "Borderline routing sample" },
];

export const sourceOptions: ReadonlyArray<{ value: ActivityEvent["source"]; label: string }> = [
  { value: "avatar-service", label: "Avatar service" },
  { value: "community-api", label: "Community API" },
  { value: "profile-upload", label: "Profile upload" },
  { value: "marketplace", label: "Marketplace" },
  { value: "comment-media", label: "Comment media" },
  { value: "partner-ingest", label: "Partner ingest" },
];

const REQUEST_FIXTURES: Record<ValidationFixture, Record<RequestMode, RequestValidation>> = {
  valid: {
    multipart: { status: 200, label: "Request shape looks valid", message: "Required image field and supported media type are present in this local fixture.", valid: true, payload: "image=@profile.jpg" },
    base64: { status: 200, label: "Request shape looks valid", message: "The local fixture contains a well-formed image data URL.", valid: true, payload: '{"image":"data:image/jpeg;base64,…"}' },
  },
  unsupported: {
    multipart: { status: 415, label: "415 · unsupported media type", message: "Use JPG, PNG, or WEBP for multipart requests.", valid: false, payload: "image=@asset.tiff" },
    base64: { status: 415, label: "415 · unsupported media type", message: "The data URL must declare image/jpeg, image/png, or image/webp.", valid: false, payload: '{"image":"data:image/tiff;base64,…"}' },
  },
  oversized: {
    multipart: { status: 413, label: "413 · payload too large", message: "Reduce the local fixture below the 10MB preview limit.", valid: false, payload: "image=@archive.png  // 12.4MB" },
    base64: { status: 413, label: "413 · payload too large", message: "Reduce the encoded image before submitting the request.", valid: false, payload: '{"image":"data:image/png;base64,…"  // 12.4MB}' },
  },
  malformed: {
    multipart: { status: 422, label: "422 · payload incomplete", message: "Attach an image field before submitting a multipart request.", valid: false, payload: "Content-Type: multipart/form-data  // missing image" },
    base64: { status: 422, label: "422 · malformed image field", message: "Use a complete image data URL, including the media type and encoded content.", valid: false, payload: '{"image":"not-a-data-url"}' },
  },
};

export function getFallbackEvents(): ActivityEvent[] {
  return BASE_EVENTS.map((event) => ({ ...event }));
}

export function normalizePassThreshold(value: number, fallback = DEFAULT_PASS_THRESHOLD): number {
  if (!Number.isFinite(value)) return fallback;
  return Math.min(MAX_PASS_THRESHOLD, Math.max(MIN_PASS_THRESHOLD, value));
}

export function getFixtureMetrics(events: readonly ActivityEvent[]): FixtureMetrics {
  if (!events.length) return { requests: 0, passRate: 0, reviewQueue: 0 };
  const safeCount = events.filter((event) => event.verdict === "safe").length;
  const reviewCount = events.filter((event) => event.verdict === "review").length;
  return { requests: 18492, passRate: (safeCount / events.length) * 100, reviewQueue: reviewCount * 9 };
}

export function filterFixtureEvents(events: readonly ActivityEvent[], filters: FixtureFilters) {
  const visible = filters.showAll ? events : events.slice(0, 4);
  const maxAge = filters.timeRange === "30m" ? 30 : filters.timeRange === "2h" ? 120 : 1440;
  const scoped = visible.filter((event) => event.ageMinutes <= maxAge);
  const filtered = scoped.filter((event) => {
    const confidenceMatches = filters.confidence === "all" || (filters.confidence === "high" ? event.score >= 0.8 : event.score < 0.8);
    return (filters.verdict === "all" || event.verdict === filters.verdict) && (filters.source === "all" || event.source === filters.source) && confidenceMatches;
  });
  return {
    scoped,
    filtered,
    counts: {
      safe: scoped.filter((event) => event.verdict === "safe").length,
      review: scoped.filter((event) => event.verdict === "review").length,
      blocked: scoped.filter((event) => event.verdict === "blocked").length,
    },
  };
}

export function getClassificationResult(fixture: ScanFixtureId, passThreshold: number): ClassificationResult {
  const samples: Record<ScanFixtureId, Omit<ClassificationResult, "verdict" | "title" | "detail"> & { actionScore: number }> = {
    "profile-photo": { actionScore: 0.91, safeConfidence: 0.91, latencyMs: 184, categories: [{ label: "neutral", score: 0.91, emphasis: "signal" }, { label: "sensitive", score: 0.04 }, { label: "policy match", score: 0.01 }] },
    "editorial-illustration": { actionScore: 0.87, safeConfidence: 0.87, latencyMs: 166, categories: [{ label: "illustration", score: 0.87, emphasis: "signal" }, { label: "neutral", score: 0.79 }, { label: "sensitive", score: 0.03 }] },
    "ambiguous-crop": { actionScore: 0.64, safeConfidence: 0.64, latencyMs: 218, categories: [{ label: "neutral", score: 0.81, emphasis: "signal" }, { label: "sensitive", score: 0.64, emphasis: "caution" }, { label: "policy match", score: 0.04 }] },
  };

  const sample = samples[fixture];
  const verdict = sample.actionScore >= normalizePassThreshold(passThreshold) ? "safe" : "review";
  return {
    ...sample,
    verdict,
    title: verdict === "safe" ? "Safe to publish" : "Send to review",
    detail: verdict === "safe" ? "The selected local sample met your configured pass threshold." : "This local sample did not meet your pass threshold. Keep it out of public view until reviewed.",
  };
}

export function getRequestValidation(fixture: ValidationFixture, mode: RequestMode): RequestValidation {
  return { ...REQUEST_FIXTURES[fixture][mode] };
}

export function getStreamStatePresentation(state: LocalStreamState): StreamStatePresentation {
  const presentation: Record<LocalStreamState, StreamStatePresentation> = {
    ready: { label: "Fixture data ready", tone: "ready", detail: "Current local fixture data is available." },
    refreshing: { label: "Refreshing fixture", tone: "refreshing", detail: "A new local fixture revision is being prepared." },
    degraded: { label: "Fallback preserved", tone: "degraded", detail: "The last known local fixture data remains visible." },
    paused: { label: "Stream paused", tone: "paused", detail: "Refreshes are paused until the local stream is resumed." },
  };
  return presentation[state];
}

export function getClassificationAnnouncement(result: ClassificationResult): string {
  return `${result.title} · ${result.safeConfidence.toFixed(2)} confidence · local fixture result.`;
}

export function formatFixtureTime(ageMinutes: number): string {
  return ageMinutes <= 1 ? "moments ago" : `${ageMinutes} min ago`;
}
