/* SafeScan Field Manual: fallback outcomes should be explicit, deterministic, and safe even when a revision value is unavailable. */
import { describe, expect, it } from "vitest";
import { getFixtureRefreshOutcome } from "./localRecovery";

describe("SafeScan local fixture recovery", () => {
  it("describes a successful local refresh without implying a network request", () => {
    expect(getFixtureRefreshOutcome(3, false)).toMatchObject({ streamState: "ready", lastRefresh: "Fixture r3 · refreshed", tone: "success" });
  });

  it("keeps the retained fixture revision explicit after a refresh failure", () => {
    expect(getFixtureRefreshOutcome(3, true)).toMatchObject({ streamState: "degraded", lastRefresh: "Fallback retained · r3", tone: "warning" });
    expect(getFixtureRefreshOutcome(Number.NaN, true).message).toContain("r1");
  });
});
