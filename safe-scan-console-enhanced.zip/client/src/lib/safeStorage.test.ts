/* SafeScan Field Manual: storage behavior is deliberately small, deterministic, and safe under restricted browser policies. */
import { describe, expect, it } from "vitest";
import { readStoredValue, type StringStorage, writeStoredValue } from "./safeStorage";

function createStorage(seed: Record<string, string> = {}): StringStorage & { values: Record<string, string> } {
  const values = { ...seed };
  return {
    values,
    getItem: (key) => values[key] ?? null,
    setItem: (key, value) => { values[key] = value; },
  };
}

const isNumber = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value);

describe("SafeScan storage helpers", () => {
  it("restores a valid stored value", () => {
    expect(readStoredValue("threshold", 0.72, isNumber, createStorage({ threshold: "0.86" }))).toBe(0.86);
  });

  it("falls back for malformed or invalid stored content", () => {
    expect(readStoredValue("threshold", 0.72, isNumber, createStorage({ threshold: "{bad" }))).toBe(0.72);
    expect(readStoredValue("threshold", 0.72, isNumber, createStorage({ threshold: "\"high\"" }))).toBe(0.72);
  });

  it("returns the fallback cleanly when no storage is available", () => {
    expect(readStoredValue("threshold", 0.72, isNumber, null)).toBe(0.72);
    expect(writeStoredValue("threshold", 0.86, null)).toBe(false);
  });

  it("reports a successful write and serializes the stored value", () => {
    const storage = createStorage();
    expect(writeStoredValue("threshold", 0.86, storage)).toBe(true);
    expect(storage.values.threshold).toBe("0.86");
  });
});
