/* SafeScan Field Manual: policy previews should be explicit local state transitions, never implicit production changes. */
import { normalizePassThreshold } from "./mockData";

export type PolicyPreviewState = {
  threshold: number;
  saved: boolean;
  approvalRequested: boolean;
};

export type PolicyPreviewOutcome = {
  state: PolicyPreviewState;
  message: string;
  tone: "success" | "warning";
};

export function editLocalPolicyThreshold(value: number, baseline: number): PolicyPreviewState {
  return { threshold: normalizePassThreshold(value, baseline), saved: false, approvalRequested: false };
}

export function saveLocalPolicyPreview(state: PolicyPreviewState, baseline: number): PolicyPreviewOutcome {
  if (state.threshold === baseline) {
    return { state, tone: "warning", message: "Change the pass threshold before saving a local policy preview." };
  }
  return {
    state: { ...state, saved: true, approvalRequested: false },
    tone: "success",
    message: "Policy preview saved locally. It has not changed a production policy.",
  };
}
