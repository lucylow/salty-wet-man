/* SafeScan Field Manual: local validation messaging should be deterministic, specific, and safe to retry. */
import { describe, expect, it } from "vitest";
import { getRequestValidation } from "./mockData";
import { getValidationOutcome } from "./localPreview";

describe("SafeScan local validation outcomes", () => {
  it("starts with an explicit no-network validation boundary", () => {
    expect(getValidationOutcome("idle", getRequestValidation("valid", "multipart"))).toMatchObject({ tone: "neutral", canSimulate: false });
  });

  it("allows simulations only after a valid local fixture has passed", () => {
    expect(getValidationOutcome("valid", getRequestValidation("valid", "base64"))).toMatchObject({ tone: "success", canSimulate: true });
    expect(getValidationOutcome("error", getRequestValidation("malformed", "base64"))).toMatchObject({ tone: "warning", canSimulate: false });
  });
});
