/* SafeScan Field Manual: deterministic fixture behavior is a safety contract and should remain verifiable. */
import { describe, expect, it } from "vitest";
import { DEFAULT_PASS_THRESHOLD, filterFixtureEvents, getClassificationAnnouncement, getClassificationResult, getFallbackEvents, getFixtureMetrics, getRequestValidation, getStreamStatePresentation, MAX_PASS_THRESHOLD, MIN_PASS_THRESHOLD, normalizePassThreshold, scanFixtures } from "./mockData";

describe("SafeScan local fixtures", () => {
  it("returns independent fallback event arrays with source and freshness context", () => {
    const first = getFallbackEvents();
    const second = getFallbackEvents();

    expect(first).toHaveLength(8);
    expect(first).not.toBe(second);
    expect(first[0]).not.toBe(second[0]);
    expect(first.every((event) => event.id && event.sourceLabel && event.ageMinutes >= 0)).toBe(true);
  });

  it("routes a local sample using the explicit pass threshold", () => {
    expect(getClassificationResult("profile-photo", 0.9)).toMatchObject({ verdict: "safe", title: "Safe to publish", safeConfidence: 0.91 });
    expect(getClassificationResult("profile-photo", 0.92)).toMatchObject({ verdict: "review", title: "Send to review" });
    expect(getClassificationResult("ambiguous-crop", 0.64)).toMatchObject({ verdict: "safe" });
    expect(getClassificationResult("ambiguous-crop", 0.65)).toMatchObject({ verdict: "review" });
  });

  it("covers supported and recoverable request-validation outcomes", () => {
    expect(getRequestValidation("valid", "multipart")).toMatchObject({ status: 200, valid: true });
    expect(getRequestValidation("unsupported", "base64")).toMatchObject({ status: 415, valid: false });
    expect(getRequestValidation("oversized", "multipart")).toMatchObject({ status: 413, valid: false });
    expect(getRequestValidation("malformed", "base64")).toMatchObject({ status: 422, valid: false });
  });

  it("keeps the local sandbox fixture catalogue complete and uniquely identified", () => {
    expect(scanFixtures).toHaveLength(3);
    expect(new Set(scanFixtures.map((fixture) => fixture.id)).size).toBe(scanFixtures.length);
  });

  it("presents every local stream state with a clear source-aware recovery message", () => {
    expect(getStreamStatePresentation("ready")).toMatchObject({ label: "Fixture data ready", tone: "ready" });
    expect(getStreamStatePresentation("refreshing").detail).toContain("revision");
    expect(getStreamStatePresentation("degraded").detail).toContain("last known");
    expect(getStreamStatePresentation("paused").detail).toContain("resumed");
  });

  it("uses a stable, explainable announcement for a local classification result", () => {
    const result = getClassificationResult("ambiguous-crop", 0.65);
    expect(getClassificationAnnouncement(result)).toBe("Send to review · 0.64 confidence · local fixture result.");
  });

  it("normalizes pass thresholds before decisions are made", () => {
    expect(normalizePassThreshold(Number.NaN)).toBe(DEFAULT_PASS_THRESHOLD);
    expect(normalizePassThreshold(-1)).toBe(MIN_PASS_THRESHOLD);
    expect(normalizePassThreshold(2)).toBe(MAX_PASS_THRESHOLD);
    expect(getClassificationResult("profile-photo", 2).verdict).toBe("review");
  });

  it("reports deterministic metrics and a safe empty fallback", () => {
    expect(getFixtureMetrics([])).toEqual({ requests: 0, passRate: 0, reviewQueue: 0 });
    expect(getFixtureMetrics(getFallbackEvents())).toMatchObject({ requests: 18492, passRate: 50, reviewQueue: 18 });
  });

  it("filters local fixtures deterministically across confidence, source, and stale-time boundaries", () => {
    const filtered = filterFixtureEvents(getFallbackEvents(), { showAll: true, verdict: "review", source: "all", confidence: "review", timeRange: "30m" });
    expect(filtered.filtered.map((event) => event.id)).toEqual(["evt_0197", "evt_0194"]);
    expect(filterFixtureEvents([], { showAll: false, verdict: "all", source: "all", confidence: "all", timeRange: "2h" })).toMatchObject({ scoped: [], filtered: [], counts: { safe: 0, review: 0, blocked: 0 } });
  });
});
