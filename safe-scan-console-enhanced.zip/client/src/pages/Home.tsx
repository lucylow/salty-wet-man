/* SafeScan Field Manual: editorial brutalism, mineral canvas, deep ink, signal orange, and explicit local-state cues. */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowUpRight,
  Check,
  ChevronDown,
  CircleHelp,
  Copy,
  FileCode2,
  Gauge,
  KeyRound,
  LayoutDashboard,
  LockKeyhole,
  Menu,
  MoreHorizontal,
  Network,
  Pause,
  Play,
  RefreshCw,
  ScanLine,
  ShieldCheck,
  Sparkles,
  Terminal,
  Upload,
  X,
} from "lucide-react";
import {
  DEFAULT_PASS_THRESHOLD,
  formatFixtureTime,
  filterFixtureEvents,
  getClassificationAnnouncement,
  getClassificationResult,
  getFallbackEvents,
  getFixtureMetrics,
  getRequestValidation,
  getStreamStatePresentation,
  MAX_PASS_THRESHOLD,
  MIN_PASS_THRESHOLD,
  normalizePassThreshold,
  scanFixtures,
  sourceOptions,
  type ActivityEvent,
  type ClassificationResult,
  type LocalStreamState,
  type RequestMode,
  type ScanFixtureId,
  type ValidationFixture,
  type Verdict,
} from "@/lib/mockData";
import { copyTextWithFallback } from "@/lib/browser";
import { getValidationOutcome, type LocalValidationState } from "@/lib/localPreview";
import { editLocalPolicyThreshold, saveLocalPolicyPreview } from "@/lib/policyPreview";
import { getFixtureRefreshOutcome } from "@/lib/localRecovery";
import { useSafeSessionState } from "@/hooks/useSafeSessionState";
import { useActionGuard } from "@/hooks/useActionGuard";

type Tab = "Overview" | "Sandbox" | "API explorer";
type StreamState = LocalStreamState;
type ConfidenceBand = "all" | "high" | "review";
type TimeRange = "30m" | "2h" | "24h";
type SourceFilter = "all" | ActivityEvent["source"];
type NoticeTone = "neutral" | "warning" | "success";
type Notice = { tone: NoticeTone; message: string } | null;

const BASELINE_THRESHOLD = DEFAULT_PASS_THRESHOLD;
const SIGNAL_LEDGER_URL = "/manus-storage/safescan-signal-ledger_cae077f4.png";
const PROVENANCE_WINDOW_URL = "/manus-storage/safescan-provenance-window_f26f2858.png";
const RECOVERY_RAIL_URL = "/manus-storage/safescan-recovery-rail_efd9e327.png";

function isTab(value: unknown): value is Tab {
  return typeof value === "string" && (value === "Overview" || value === "Sandbox" || value === "API explorer");
}

function isRequestMode(value: unknown): value is RequestMode {
  return typeof value === "string" && (value === "multipart" || value === "base64");
}

function isValidationFixture(value: unknown): value is ValidationFixture {
  return typeof value === "string" && (value === "valid" || value === "unsupported" || value === "oversized" || value === "malformed");
}

function isScanFixture(value: unknown): value is ScanFixtureId {
  return typeof value === "string" && scanFixtures.some((fixture) => fixture.id === value);
}

function isVerdict(value: unknown): value is "all" | Verdict {
  return typeof value === "string" && (value === "all" || value === "safe" || value === "review" || value === "blocked");
}

function isSourceFilter(value: unknown): value is SourceFilter {
  return typeof value === "string" && (value === "all" || sourceOptions.some((source) => source.value === value));
}

function isConfidenceBand(value: unknown): value is ConfidenceBand {
  return typeof value === "string" && (value === "all" || value === "high" || value === "review");
}

function isTimeRange(value: unknown): value is TimeRange {
  return typeof value === "string" && (value === "30m" || value === "2h" || value === "24h");
}

function clampThreshold(value: number): number {
  return normalizePassThreshold(value, BASELINE_THRESHOLD);
}

function isThreshold(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value) && value >= MIN_PASS_THRESHOLD && value <= MAX_PASS_THRESHOLD;
}

function isFixtureRevision(value: unknown): value is number {
  return typeof value === "number" && Number.isInteger(value) && value >= 1 && value <= 9999;
}

function StatusDot({ verdict }: { verdict: Verdict }) {
  return <span className={`status-dot ${verdict}`} aria-hidden="true" />;
}

function AppLogo() {
  return <span className="app-logo" aria-label="SafeScan inspection mark"><img className="app-logo-image" src="/manus-storage/safescan-inspection-mark_0fafbe80.png" alt="" /><i className="brand-scan-line" /></span>;
}

function FallbackBadge({ state }: { state: StreamState }) {
  const presentation = getStreamStatePresentation(state);
  return <span className={`fallback-badge ${presentation.tone}`} title={presentation.detail}><i />{presentation.label}</span>;
}

export default function Home() {
  const [activeTab, setActiveTab] = useSafeSessionState<Tab>("safescan.active-tab", "Overview", isTab);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notice, setNotice] = useState<Notice>({ tone: "warning", message: "Prototype workspace — all responses remain local. Connect a backend before making real moderation decisions." });
  const [events, setEvents] = useState<ActivityEvent[]>(() => getFallbackEvents());
  const [streamState, setStreamState] = useState<StreamState>("ready");
  const [fixtureRevision, setFixtureRevision] = useSafeSessionState<number>("safescan.fixture-revision", 1, isFixtureRevision);
  const [lastRefresh, setLastRefresh] = useState(`Fixture r${fixtureRevision} · ready`);
  const [showAllEvents, setShowAllEvents] = useState(false);
  const [filterVerdict, setFilterVerdict] = useState<"all" | Verdict>("all");
  const [filterSource, setFilterSource] = useState<SourceFilter>("all");
  const [filterConfidence, setFilterConfidence] = useState<ConfidenceBand>("all");
  const [filterTimeRange, setFilterTimeRange] = useState<TimeRange>("2h");
  const [passThreshold, setPassThreshold] = useSafeSessionState<number>("safescan.pass-threshold", BASELINE_THRESHOLD, isThreshold);
  const [selectedFixture, setSelectedFixture] = useSafeSessionState<ScanFixtureId>("safescan.scan-fixture", "profile-photo", isScanFixture);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ClassificationResult | null>(null);
  const [scanError, setScanError] = useState("");
  const [policyThreshold, setPolicyThreshold] = useSafeSessionState<number>("safescan.policy-threshold", BASELINE_THRESHOLD, isThreshold);
  const [policySaved, setPolicySaved] = useState(false);
  const [approvalRequested, setApprovalRequested] = useState(false);
  const [showPolicyDiff, setShowPolicyDiff] = useState(false);
  const [showPolicyHistory, setShowPolicyHistory] = useState(false);
  const [requestMode, setRequestMode] = useSafeSessionState<RequestMode>("safescan.request-mode", "multipart", isRequestMode);
  const [validationFixture, setValidationFixture] = useState<ValidationFixture>("valid");
  const [validationStatus, setValidationStatus] = useState<LocalValidationState>("idle");
  const [simulationRan, setSimulationRan] = useState(false);
  const [copied, setCopied] = useState<"request" | "payload" | null>(null);
  const timerRefs = useRef<Set<number>>(new Set());
  const noticeTimerRef = useRef<number | null>(null);
  const copyTimerRef = useRef<number | null>(null);
  const streamAction = useActionGuard();
  const scanAction = useActionGuard();

  const schedule = useCallback((callback: () => void, delay: number) => {
    if (typeof window === "undefined" || !Number.isFinite(delay) || delay < 0) return null;
    const timer = window.setTimeout(() => {
      timerRefs.current.delete(timer);
      callback();
    }, delay);
    timerRefs.current.add(timer);
    return timer;
  }, []);

  const clearScheduledTimer = useCallback((timer: number | null) => {
    if (typeof window === "undefined" || timer === null) return;
    window.clearTimeout(timer);
    timerRefs.current.delete(timer);
  }, []);

  useEffect(() => () => {
    if (typeof window !== "undefined") timerRefs.current.forEach((timer) => window.clearTimeout(timer));
    timerRefs.current.clear();
    noticeTimerRef.current = null;
    copyTimerRef.current = null;
  }, []);

  const announce = useCallback((message: string, tone: NoticeTone = "neutral") => {
    clearScheduledTimer(noticeTimerRef.current);
    setNotice({ message, tone });
    noticeTimerRef.current = schedule(() => {
      noticeTimerRef.current = null;
      setNotice(null);
    }, 5200);
  }, [clearScheduledTimer, schedule]);

  const setTab = useCallback((tab: Tab) => {
    setActiveTab(tab);
    setSidebarOpen(false);
  }, []);

  const refreshFixtureData = useCallback((forceFailure = false) => {
    if (streamState === "paused") {
      announce("Resume the local stream before refreshing its fixtures.", "warning");
      return;
    }
    if (streamState === "refreshing" || !streamAction.begin()) return;
    setStreamState("refreshing");
    const refreshTimer = schedule(() => {
      streamAction.release();
      if (forceFailure) {
        const outcome = getFixtureRefreshOutcome(fixtureRevision, true);
        setStreamState(outcome.streamState);
        setLastRefresh(outcome.lastRefresh);
        announce(outcome.message, outcome.tone);
        return;
      }
      const nextRevision = fixtureRevision + 1;
      const outcome = getFixtureRefreshOutcome(nextRevision, false);
      setEvents(getFallbackEvents());
      setFixtureRevision(nextRevision);
      setStreamState(outcome.streamState);
      setLastRefresh(outcome.lastRefresh);
      announce(outcome.message, outcome.tone);
    }, 520);
    if (refreshTimer === null) {
      streamAction.release();
      const outcome = getFixtureRefreshOutcome(fixtureRevision, true);
      setStreamState(outcome.streamState);
      setLastRefresh(outcome.lastRefresh);
      announce("Local fixture refresh is unavailable in this environment. Existing fixture data was preserved.", "warning");
    }
  }, [announce, fixtureRevision, schedule, setFixtureRevision, streamAction, streamState]);

  const runScan = useCallback(() => {
    if (isScanning || !scanAction.begin()) return;
    if (!isScanFixture(selectedFixture)) {
      scanAction.release();
      setScanError("The selected sample is unavailable. Choose another local sample and try again.");
      return;
    }
    setIsScanning(true);
    setScanError("");
    setScanResult(null);
    const scanSnapshot = { fixture: selectedFixture, threshold: passThreshold };
    try {
      const scanTimer = schedule(() => {
        const result = getClassificationResult(scanSnapshot.fixture, scanSnapshot.threshold);
        setScanResult(result);
        scanAction.release();
        setIsScanning(false);
        announce(getClassificationAnnouncement(result), result.verdict === "safe" ? "success" : "warning");
      }, 760);
      if (scanTimer === null) throw new Error("Timer unavailable");
    } catch {
      scanAction.release();
      setIsScanning(false);
      setScanError("Preview could not start. No image was uploaded and your settings were preserved.");
    }
  }, [announce, isScanning, passThreshold, scanAction, schedule, selectedFixture]);

  const selectedValidation = useMemo(() => getRequestValidation(validationFixture, requestMode), [requestMode, validationFixture]);
  const validationOutcome = useMemo(() => getValidationOutcome(validationStatus, selectedValidation), [selectedValidation, validationStatus]);
  const requestSnippet = useMemo(() => requestMode === "multipart"
    ? "curl https://api.safescan.dev/v1/classify \\\n+  -H 'Authorization: Bearer sk_live_••••' \\\n+  -F 'image=@profile.jpg'"
    : "curl https://api.safescan.dev/v1/classify \\\n+  -H 'Authorization: Bearer sk_live_••••' \\\n+  -H 'Content-Type: application/json' \\\n+  -d '{\"image\":\"data:image/jpeg;base64,…\"}'", [requestMode]);

  const validateRequest = useCallback(() => {
    setSimulationRan(false);
    const nextState: LocalValidationState = selectedValidation.valid ? "valid" : "error";
    const outcome = getValidationOutcome(nextState, selectedValidation);
    setValidationStatus(nextState);
    announce(outcome.detail, outcome.tone);
  }, [announce, selectedValidation]);

  const runSimulation = useCallback(() => {
    if (!validationOutcome.canSimulate) {
      setValidationStatus("error");
      announce("Validate a valid local request fixture before running the response simulation.", validationOutcome.tone === "success" ? "warning" : validationOutcome.tone);
      return;
    }
    setSimulationRan(true);
    announce("Local response simulation complete. No credentials or media were used.", "success");
  }, [announce, validationOutcome]);

  const copyText = useCallback(async (text: string, kind: "request" | "payload") => {
    if (await copyTextWithFallback(text)) {
      clearScheduledTimer(copyTimerRef.current);
      setCopied(kind);
      copyTimerRef.current = schedule(() => {
        copyTimerRef.current = null;
        setCopied(null);
      }, 1800);
    } else {
      announce("Clipboard access was blocked. Select the visible code and copy it manually.", "warning");
    }
  }, [announce, clearScheduledTimer, schedule]);

  const streamSnapshot = useMemo(() => filterFixtureEvents(events, { showAll: showAllEvents, verdict: filterVerdict, source: filterSource, confidence: filterConfidence, timeRange: filterTimeRange }), [events, filterConfidence, filterSource, filterTimeRange, filterVerdict, showAllEvents]);
  const timeScopedEvents = streamSnapshot.scoped;
  const filteredEvents = streamSnapshot.filtered;
  const activeFilterCount = [filterVerdict !== "all", filterSource !== "all", filterConfidence !== "all", filterTimeRange !== "2h"].filter(Boolean).length;
  const streamCounts = streamSnapshot.counts;
  const mockMetrics = useMemo(() => getFixtureMetrics(events), [events]);
  const selectedScanFixture = useMemo(() => scanFixtures.find((fixture) => fixture.id === selectedFixture) ?? scanFixtures[0], [selectedFixture]);

  const resetFilters = () => {
    setFilterVerdict("all");
    setFilterSource("all");
    setFilterConfidence("all");
    setFilterTimeRange("2h");
  };

  const savePolicyPreview = () => {
    const outcome = saveLocalPolicyPreview({ threshold: policyThreshold, saved: policySaved, approvalRequested }, BASELINE_THRESHOLD);
    setPolicyThreshold(outcome.state.threshold);
    setPolicySaved(outcome.state.saved);
    setApprovalRequested(outcome.state.approvalRequested);
    announce(outcome.message, outcome.tone);
  };

  const updatePolicyThreshold = (value: string) => {
    const nextState = editLocalPolicyThreshold(Number(value), BASELINE_THRESHOLD);
    setPolicyThreshold(nextState.threshold);
    setPolicySaved(nextState.saved);
    setApprovalRequested(nextState.approvalRequested);
  };

  const navigationItems: ReadonlyArray<{ icon: typeof LayoutDashboard; label: Tab }> = [
    { icon: LayoutDashboard, label: "Overview" },
    { icon: ScanLine, label: "Sandbox" },
    { icon: FileCode2, label: "API explorer" },
  ];

  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="brand-lockup"><AppLogo /><div><strong>SafeScan</strong><span>moderation layer</span></div></div>
        <button className="workspace-switcher" onClick={() => announce("Northstar Labs is the active local workspace.")}><span className="workspace-mark">N</span><span><small>WORKSPACE</small><b>Northstar Labs</b></span><ChevronDown size={15} /></button>
        <nav className="side-nav" aria-label="Primary navigation">
          <small className="nav-label">Workspace</small>
          {navigationItems.map(({ icon: Icon, label }) => <button key={label} className={activeTab === label ? "active" : ""} onClick={() => setTab(label)}><Icon size={17} /><span>{label}</span>{label === "Sandbox" && <em>try it</em>}</button>)}
          <small className="nav-label">Infrastructure</small>
          <button onClick={() => announce("Usage limits need a connected backend. The console is showing local fixtures only.")}><Activity size={17} /><span>Usage & limits</span></button>
          <button onClick={() => announce("API key management is not persisted in this static console.")}><KeyRound size={17} /><span>API keys</span></button>
          <button onClick={() => announce("Webhook delivery is not connected in this static console.")}><Network size={17} /><span>Webhooks</span></button>
        </nav>
        <div className="sidebar-bottom"><div className="privacy-note"><LockKeyhole size={15} /><span><b>Privacy mode on</b><small>Samples are not retained.</small></span></div><button className="help-button" onClick={() => announce("Documentation links can be connected once the API is available.")}><CircleHelp size={16} />Documentation <ArrowUpRight size={14} /></button><div className="user-row"><div className="avatar">JL</div><span><b>Jordan Lee</b><small>Owner</small></span><MoreHorizontal size={17} /></div></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><button className="mobile-menu" onClick={() => setSidebarOpen((current) => !current)} aria-label="Toggle menu"><Menu size={20} /></button><div className="breadcrumb"><span>Northstar Labs</span><b>/</b><strong>{activeTab}</strong></div><div className="top-actions"><span className="status-live"><i /> Local system ready</span><button className="icon-button" aria-label="Open help" onClick={() => announce("Each control is a local simulation. Your selections remain in this browser session.")}><CircleHelp size={18} /></button><button className="profile-mini" onClick={() => announce("Account settings require a connected identity service.")}>JL</button></div></header>
        {notice && <div className={`action-notice ${notice.tone}`} role="status" aria-live="polite"><span>{notice.tone === "warning" && <AlertTriangle size={13} />}{notice.tone === "success" && <Check size={13} />}{notice.message}</span><button onClick={() => setNotice(null)} aria-label="Dismiss notice"><X size={13} /></button></div>}

        <div className="content-wrap">
          <section className="page-heading"><div><div className="eyebrow"><span>Workspace / 01</span><i /></div><h1>{activeTab === "Overview" ? "Know what crossed the line." : activeTab === "Sandbox" ? "Test a decision before it ships." : "One endpoint. Clear outcomes."}</h1><p>{activeTab === "Overview" ? "A quiet layer between user uploads and public surfaces. This local console makes the decision source, fallback status, and recovery path visible." : activeTab === "Sandbox" ? "Run a sample against the current local policy. No file, credential, or decision is sent outside this browser." : "Validate predictable request fixtures before you wire a moderation endpoint into the rest of your upload pipeline."}</p></div><div className="heading-meta"><span>Policy</span><b>ugc-default-v2</b><small>Local preview · {lastRefresh}</small></div></section>
          <div className="tab-row" role="tablist" aria-label="SafeScan views">{(["Overview", "Sandbox", "API explorer"] as Tab[]).map((tab) => <button key={tab} role="tab" aria-selected={activeTab === tab} className={activeTab === tab ? "selected" : ""} onClick={() => setTab(tab)}>{tab}{tab === "Sandbox" && <span className="new-tag">LOCAL</span>}</button>)}</div>

          {activeTab === "Overview" && <>
            <section className="decision-bands"><article className="metric-card accent-card"><div className="metric-top"><span>Fixture requests</span><Activity size={16} /></div><strong>{mockMetrics.requests.toLocaleString()}</strong><div className="metric-foot"><span className="up">Local set</span><small>{events.length} deterministic records</small></div><div className="mini-bars" aria-hidden="true">{[35, 52, 41, 65, 58, 79, 68, 92, 76, 84, 72, 98].map((height, index) => <i key={index} style={{ height: `${height}%` }} />)}</div></article><article className="metric-card"><div className="metric-top"><span>Safe pass rate</span><ShieldCheck size={16} /></div><strong>{mockMetrics.passRate.toFixed(1)}<span>%</span></strong><div className="metric-foot"><span className="up">Source clear</span><small>based on visible fixtures</small></div><div className="progress-line"><i style={{ width: `${mockMetrics.passRate}%` }} /></div></article><article className="metric-card"><div className="metric-top"><span>Review queue</span><Gauge size={16} /></div><strong>{mockMetrics.reviewQueue}</strong><div className="metric-foot"><span className="neutral">Local only</span><small>no reviewer assigned</small></div><div className="queue-line"><i /><i /><i /><i /><i /><i /></div></article></section>
            <section className="signal-hero"><img src={SIGNAL_LEDGER_URL} alt="Abstract moderation audit ledger with scan marks" /><div className="signal-hero-copy"><span className="section-kicker">Decision source / 01A</span><h2>Know which signal you are looking at.</h2><p>Every visible number is a typed, deterministic local fixture. When a simulated refresh fails, the last safe fixture remains readable instead of disappearing.</p><div><FallbackBadge state={streamState} /><button className="text-button" onClick={() => refreshFixtureData(false)} disabled={streamState === "refreshing"}>{streamState === "refreshing" ? <RefreshCw className="spin-icon" size={14} /> : <RefreshCw size={14} />} Reload fixtures</button></div></div></section>
            <section className="workspace-grid"><article className="panel event-panel"><div className="panel-heading"><div><span className="section-kicker">Local event stream</span><h2>Recent decisions</h2></div><button className="text-button" onClick={() => setShowAllEvents((current) => !current)}>{showAllEvents ? "Show fewer" : "View all"} <ArrowUpRight size={14} /></button></div><div className="event-filter"><span>Filter decisions</span><select value={filterVerdict} onChange={(event) => isVerdict(event.target.value) && setFilterVerdict(event.target.value)} aria-label="Filter decisions"><option value="all">All verdicts</option><option value="safe">Safe</option><option value="review">Review</option><option value="blocked">Blocked</option></select><select value={filterSource} onChange={(event) => isSourceFilter(event.target.value) && setFilterSource(event.target.value)} aria-label="Filter sources"><option value="all">All sources</option>{sourceOptions.map((source) => <option key={source.value} value={source.value}>{source.label}</option>)}</select><select value={filterConfidence} onChange={(event) => isConfidenceBand(event.target.value) && setFilterConfidence(event.target.value)} aria-label="Filter confidence"><option value="all">All confidence</option><option value="high">High ≥ 0.80</option><option value="review">Review band</option></select><select value={filterTimeRange} onChange={(event) => isTimeRange(event.target.value) && setFilterTimeRange(event.target.value)} aria-label="Filter time range"><option value="30m">30 minutes</option><option value="2h">2 hours</option><option value="24h">24 hours</option></select><button className="reset-filters" disabled={!activeFilterCount} onClick={resetFilters}>{activeFilterCount ? `Reset ${activeFilterCount}` : "Filters clear"}</button></div><div className="event-summary"><FallbackBadge state={streamState} /><span className="event-scope">{filteredEvents.length} shown · {timeScopedEvents.length} in scope</span><span><i className="safe" />{streamCounts.safe} safe</span><span><i className="review" />{streamCounts.review} review</span><span><i className="blocked" />{streamCounts.blocked} blocked</span></div><div className="table-head"><span>Time</span><span>Source</span><span>Decision</span><span>Confidence</span></div>{filteredEvents.map((event) => <div className="event-row" key={event.id}><span className="mono muted">{event.time}<small>{formatFixtureTime(event.ageMinutes)}</small></span><span className="source"><span className={`source-icon ${event.verdict}`}><Upload size={13} /></span>{event.sourceLabel}</span><span className={`verdict ${event.verdict}`}><StatusDot verdict={event.verdict} />{event.verdict[0].toUpperCase() + event.verdict.slice(1)}<small>{event.label}</small></span><span className="mono">{event.score.toFixed(2)}</span></div>)}{filteredEvents.length === 0 && <div className="filtered-empty"><b>No local decisions match this filter.</b><span>Widen the verdict, source, confidence, or time selection to restore the fixture rows.</span><button className="text-button" onClick={resetFilters}>Clear filters <ArrowUpRight size={13} /></button></div>}<div className="stream-footer"><button className={`stream-control ${streamState === "paused" ? "paused" : ""}`} onClick={() => setStreamState((current) => current === "paused" ? "ready" : "paused")}>{streamState === "paused" ? <Play size={12} /> : <Pause size={12} />} {streamState === "paused" ? "Stream paused" : "Local stream active"}</button><div><button className="stream-action" onClick={() => refreshFixtureData(false)} disabled={streamState === "refreshing"}>Refresh</button><button className="stream-action danger" onClick={() => refreshFixtureData(true)} disabled={streamState === "refreshing"}>Test fallback</button></div></div></article><article className="panel policy-panel"><div className="panel-heading"><div><span className="section-kicker">Current policy</span><h2>ugc-default-v2</h2></div><button className="icon-button" aria-label="Explain policy behavior" onClick={() => announce("Higher pass thresholds route more uncertain samples to review. This is a local preview only.")}><CircleHelp size={17} /></button></div><div className="policy-body"><div className="policy-score"><div className="score-ring"><span>{policyThreshold.toFixed(2)}</span><small>pass threshold</small></div><div><b>{policyThreshold >= 0.82 ? "Strict" : policyThreshold <= 0.58 ? "Permissive" : "Balanced"}</b><p>Higher thresholds keep more borderline signals out of automatic publication.</p></div></div><div className="policy-rule"><span>Fast model</span><b>Local classifier fixture</b><small>166–218ms range</small></div><div className="policy-rule"><span>Fallback</span><b>Human review route</b><small>Preserves context on failure</small></div><div className="policy-threshold"><div><span>Pass threshold</span><b>{policyThreshold.toFixed(2)}</b></div><input type="range" min="0.4" max="0.95" step="0.01" value={policyThreshold} onChange={(event) => updatePolicyThreshold(event.target.value)} aria-label="Policy pass threshold" /></div><div className={`policy-change ${policySaved ? "saved" : policyThreshold !== BASELINE_THRESHOLD ? "dirty" : ""}`}><span>{policySaved ? "Preview saved locally" : policyThreshold !== BASELINE_THRESHOLD ? "Unsaved local preview" : "No pending changes"}</span><div><button onClick={savePolicyPreview} disabled={policyThreshold === BASELINE_THRESHOLD || policySaved}>{policySaved ? "Saved" : "Save preview"}</button><button className="reset-preview" onClick={() => { setPolicyThreshold(BASELINE_THRESHOLD); setPolicySaved(false); setApprovalRequested(false); }}>Reset</button></div></div><button className={`policy-diff-toggle ${policyThreshold === BASELINE_THRESHOLD ? "baseline" : "changed"}`} onClick={() => setShowPolicyDiff((current) => !current)}><span>Saved v2 → preview</span><b>{BASELINE_THRESHOLD.toFixed(2)} → {policyThreshold.toFixed(2)} <ArrowUpRight size={12} /></b></button>{showPolicyDiff && <div className="policy-diff-detail"><div><span>Threshold delta</span><b>{`${policyThreshold > BASELINE_THRESHOLD ? "+" : ""}${(policyThreshold - BASELINE_THRESHOLD).toFixed(2)}`}</b></div><p>{policyThreshold > BASELINE_THRESHOLD ? "A stricter pass boundary sends more local samples to review." : policyThreshold < BASELINE_THRESHOLD ? "A lower pass boundary allows more local samples to proceed automatically." : "The preview matches the saved policy baseline."}</p></div>}<div className="policy-history"><span>{approvalRequested ? "Review requested locally" : policySaved ? "Ready for review" : "Change history"}</span><div className="policy-history-actions"><button className="text-button" onClick={() => setShowPolicyHistory((current) => !current)}>{showPolicyHistory ? "Hide" : "View"} v2 changes <ArrowUpRight size={13} /></button><button className="request-approval" onClick={() => { if (!policySaved) { announce("Save the local policy preview before requesting a review.", "warning"); return; } setApprovalRequested((current) => !current); }} disabled={!policySaved}>{approvalRequested ? "Cancel request" : "Request review"}</button></div></div>{showPolicyHistory && <div className="history-detail"><b>v2 · current local baseline</b><span>Pass threshold {BASELINE_THRESHOLD.toFixed(2)} · review route retained</span><small>Rollback and reviewer assignment require a backend.</small></div>}<button className="outline-button" onClick={() => setTab("Sandbox")}>Run a sample <Play size={14} fill="currentColor" /></button></div></article></section>
            <section className="governance-strip"><div className="governance-intro"><span className="section-kicker">Data governance / 02</span><h2>Every decision has a paper trail.</h2><p>Local fallback data retains the same source, confidence, and decision vocabulary as a connected service would expose.</p></div><div className="governance-cells"><div><span>Dataset lineage</span><b>Mapped</b><small>6 fixture sources</small></div><div><span>Quality gate</span><b>Passing</b><small>typed edge cases</small></div><div><span>Fallback mode</span><b>Visible</b><small>last data preserved</small></div><div><span>Retention</span><b>Zero by default</b><small>browser session only</small></div></div></section>
            <section className="assurance-grid"><article><img src={PROVENANCE_WINDOW_URL} alt="Abstract provenance contact sheet with inspection marks" /><div><span className="section-kicker">Provenance</span><h2>Source context remains attached.</h2><p>Fixture events keep their origin, relative freshness, score, and route so empty states do not erase the reason for a decision.</p></div></article><article><img src={RECOVERY_RAIL_URL} alt="Abstract reliability signal rail progressing to ready" /><div><span className="section-kicker">Recovery rail</span><h2>Failure should not look like silence.</h2><p>Test the degraded state above: the console marks the fallback explicitly while preserving the last known fixture rows.</p></div></article></section>
            <section className="safety-band"><div className="safety-band-mark"><ShieldCheck size={20} /><span>SAFETY POSTURE</span></div><div><h2>Secure by design, explicit by default.</h2><p>Production enforcement belongs in the API layer: validate file signatures and dimensions, apply per-key limits, hash secrets, record audit events, and keep retention opt-in.</p></div><div className="safety-tags"><span>Input validation</span><span>Fallback state</span><span>Key rotation</span><span>Audit-ready</span></div></section>
          </>}

          {activeTab === "Sandbox" && <section className="sandbox-layout"><article className="panel sandbox-panel"><div className="panel-heading"><div><span className="section-kicker">Policy playground</span><h2>Classify a local sample</h2></div><span className="local-badge"><LockKeyhole size={13} /> no upload</span></div><label className="sample-picker"><span>Sample fixture</span><select value={selectedFixture} onChange={(event) => { if (isScanFixture(event.target.value)) { setSelectedFixture(event.target.value); setScanResult(null); setScanError(""); } }}><option value="profile-photo">Profile photo</option><option value="editorial-illustration">Editorial illustration</option><option value="ambiguous-crop">Ambiguous crop</option></select><small>{selectedScanFixture.description}</small></label><button className="dropzone" onClick={runScan} disabled={isScanning}><div className={`drop-icon ${isScanning ? "scanning" : ""}`}><ScanLine size={28} /></div><b>{isScanning ? "Reading signal…" : "Use this local sample"}</b><span>{isScanning ? "A deterministic result is being prepared." : "Click to run a safe, browser-only fixture."}</span><small>No file picker · no media retention</small>{isScanning && <div className="scan-sweep" />}</button>{scanError && <div className="sandbox-error" role="alert"><b>Preview could not start.</b><span>{scanError}</span><button onClick={runScan}>Retry preview</button></div>}<div className="threshold-control"><div><span>Pass threshold</span><b>{passThreshold.toFixed(2)}</b></div><input type="range" min="0.4" max="0.95" step="0.01" value={passThreshold} onChange={(event) => { setPassThreshold(clampThreshold(Number(event.target.value))); setScanResult(null); }} aria-label="Pass threshold" /><div className="range-labels"><span>More permissive</span><span>More strict</span></div></div><button className="primary-button" onClick={runScan} disabled={isScanning}>{isScanning ? "Analyzing…" : "Run classification"}<ArrowUpRight size={16} /></button></article><article className={`panel decision-panel ${scanResult ? scanResult.verdict : "empty"}`}><div className="panel-heading"><div><span className="section-kicker">Decision preview</span><h2>{scanResult ? "Result received" : "Waiting for a sample"}</h2></div><span className="latency">{scanResult ? `${scanResult.latencyMs}ms` : "—"}</span></div>{scanResult ? <div className="decision-result"><div className="decision-icon">{scanResult.verdict === "safe" ? <Check size={24} /> : <AlertTriangle size={24} />}</div><span className="decision-label">{scanResult.verdict === "safe" ? "PASS" : "REVIEW"}</span><h3>{scanResult.title}</h3><p>{scanResult.detail}</p><div className="confidence-list">{scanResult.categories.map((category) => <div key={category.label}><span>{category.label}</span><b>{category.score.toFixed(2)}</b><i><em className={category.emphasis === "caution" ? "orange" : ""} style={{ width: `${category.score * 100}%` }} /></i></div>)}</div><div className="json-chip"><Terminal size={14} /> local-response.json <Copy size={14} /></div></div> : <div className="empty-result"><Sparkles size={22} /><p>Choose a sample, set the pass threshold, then run a local classification preview with an explainable outcome.</p></div>}</article></section>}

          {activeTab === "API explorer" && <><section className="api-layout"><article className="panel api-copy"><div className="panel-heading"><div><span className="section-kicker">Quick integration</span><h2>Validate before you wire it in</h2></div><span className="method-badge">POST</span></div><div className="request-modes" role="tablist" aria-label="Request body format"><span>Request body</span><button className={requestMode === "multipart" ? "active" : ""} onClick={() => { setRequestMode("multipart"); setValidationStatus("idle"); setSimulationRan(false); }} role="tab" aria-selected={requestMode === "multipart"}>multipart</button><button className={requestMode === "base64" ? "active" : ""} onClick={() => { setRequestMode("base64"); setValidationStatus("idle"); setSimulationRan(false); }} role="tab" aria-selected={requestMode === "base64"}>base64 JSON</button></div><div className="endpoint"><span>https://api.safescan.dev</span><b>/v1/classify</b></div><p>Test predictable success and failure responses locally before connecting your upload pipeline to a live moderation service.</p><div className="request-meta"><span><i className="meta-check" />{requestMode === "multipart" ? "JPG / PNG / WEBP" : "image data URL"}</span><span><i className="meta-check" />{requestMode === "multipart" ? "≤ 10MB" : "JSON payload"}</span></div><div className="validation-fixture"><span>Test edge case</span><select value={validationFixture} onChange={(event) => { if (isValidationFixture(event.target.value)) { setValidationFixture(event.target.value); setValidationStatus("idle"); setSimulationRan(false); } }} aria-label="Select validation test case"><option value="valid">Valid payload</option><option value="unsupported">Unsupported format</option><option value="oversized">Oversized payload</option><option value="malformed">Malformed payload</option></select></div><div className={`request-check ${validationStatus === "error" ? "error" : validationStatus === "valid" ? "valid" : ""}`}><b>{validationStatus === "idle" ? "Validate before sending" : selectedValidation.label}</b><span>{validationStatus === "idle" ? "The preview checks required fields locally and never transmits this fixture." : selectedValidation.message}</span></div><div className="validation-actions"><button className="outline-button validate-button" onClick={validateRequest}>{validationStatus === "error" ? "Retry validation" : "Validate local fixture"}</button>{validationStatus !== "idle" && <button className="clear-validation" onClick={() => { setValidationStatus("idle"); setSimulationRan(false); }}>Clear</button>}</div><button className="simulation-button" onClick={runSimulation} disabled={validationStatus !== "valid" || !selectedValidation.valid}>{simulationRan ? <><Check size={14} /> Simulation complete</> : <>Run local simulation <Play size={14} fill="currentColor" /></>}</button><button className="primary-button" onClick={() => announce("API keys are not created in this static preview. Connect a secure backend to manage credentials.", "warning")}>Create an API key <ArrowUpRight size={16} /></button></article><article className="code-panel"><div className="code-top"><span><span className="code-dot orange" /><span className="code-dot" /><span className="code-dot" /></span><button onClick={() => copyText(requestSnippet, "request")}>{copied === "request" ? <Check size={14} /> : <Copy size={14} />}{copied === "request" ? "Copied" : "Copy request"}</button></div><div className="payload-caption"><span>{requestMode === "multipart" ? "Multipart payload" : "Base64 JSON payload"}</span><small>Local fixture only</small><button className="payload-copy" onClick={() => copyText(selectedValidation.payload, "payload")}>{copied === "payload" ? <><Check size={12} /> Copied</> : <><Copy size={12} /> Copy payload</>}</button></div><pre><code>{requestSnippet}</code></pre><div className="response-preview"><span className={`response-label ${validationStatus === "error" ? "error" : validationStatus === "valid" ? "valid" : ""}`}>{validationStatus === "error" ? `${selectedValidation.status} · LOCAL` : simulationRan ? "200 OK · LOCAL" : validationStatus === "valid" ? "Request valid · LOCAL" : "Preview response · LOCAL"}</span><pre><code>{JSON.stringify(simulationRan ? { safe: true, confidence: 0.91, category: "neutral", retained: false, source: "local-fixture" } : { safe: null, confidence: null, category: null, retained: false, source: "awaiting-validation" }, null, 2)}</code></pre><div className="response-meta"><span><b>{simulationRan ? "184ms" : "—"}</b><small>simulated latency</small></span><span><b>{simulationRan ? "miss" : "—"}</b><small>cache state</small></span><span><b>v2</b><small>policy fixture</small></span></div><div className="response-explain"><span>Fallback behavior</span><b>{validationStatus === "error" ? "Request blocked locally" : simulationRan ? "Result is a local fixture" : "No network activity"}</b><p>{validationStatus === "error" ? "The invalid case stayed visible with its recoverable reason and payload hint." : "Connect a backend to replace fixtures with a real API response."}</p></div></div></article></section><section className="model-ladder"><div className="model-ladder-intro"><span className="section-kicker">Model ladder / 03</span><h2>Choose the right kind of certainty.</h2><p>Start with a fast first pass, add a calibrated second opinion for the uncertain edge, and retain an explainable fallback path.</p></div><div className="model-steps"><div className="model-step active"><span>01 / Fast</span><b>First-pass classifier</b><small>Low latency · high volume</small><i /></div><div className="model-step"><span>02 / Review</span><b>Uncertainty route</b><small>Ambiguous cases · human context</small><i /></div><div className="model-step"><span>03 / Recover</span><b>Last known safe state</b><small>Explicit degraded status</small><i /></div></div></section></>}
        </div>
      </main>
    </div>
  );
}
