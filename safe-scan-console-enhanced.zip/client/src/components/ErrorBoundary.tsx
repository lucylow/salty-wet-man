/* SafeScan Field Manual: global recovery stays calm, preserves privacy, and never exposes internal stack details. */
import { cn } from "@/lib/utils";
import { AlertTriangle, RotateCcw } from "lucide-react";
import { Component, ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorName: string | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, errorName: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, errorName: error.name || "UnknownError" };
  }

  private retry = () => {
    this.setState({ hasError: false, errorName: null });
  };

  private reload = () => {
    try {
      if (typeof window === "undefined" || typeof window.location?.reload !== "function") {
        throw new Error("Reload unavailable");
      }
      window.location.reload();
    } catch {
      this.retry();
    }
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex items-center justify-center min-h-screen p-8 bg-background text-foreground">
          <div className="flex flex-col items-center w-full max-w-2xl p-8 bg-card text-card-foreground border border-border shadow-sm">
            <AlertTriangle
              size={48}
              className="text-destructive mb-6 flex-shrink-0"
            />

            <p className="font-mono text-[10px] tracking-[0.12em] uppercase text-primary mb-3">Recovery note / 00</p>
            <h2 className="text-2xl font-semibold tracking-tight mb-3">The console needs a clean restart.</h2>

            <div className="p-4 w-full bg-muted overflow-auto mb-6 text-center">
              <p className="text-sm text-muted-foreground leading-6">Your local settings are retained when possible. No internal error details are shown in the workspace.</p>
              <p className="font-mono text-[10px] text-muted-foreground mt-3">Reference: {this.state.errorName}</p>
            </div>

            <div className="flex flex-wrap justify-center gap-3">
              <button onClick={this.retry} className={cn("flex items-center gap-2 px-4 py-2", "bg-primary text-primary-foreground", "hover:opacity-90 cursor-pointer")}>
                <RotateCcw size={16} />
                Try again
              </button>
              <button onClick={this.reload} className="flex items-center gap-2 px-4 py-2 border border-border text-muted-foreground hover:text-foreground cursor-pointer">
                Reload console
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
