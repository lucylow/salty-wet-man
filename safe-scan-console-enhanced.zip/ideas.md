# SafeScan product direction

## Three possible approaches

### Theme Name: Field Manual
Very Brief Intro: A tactile editorial operations console that makes moderation feel calm, accountable, and usable under pressure. Warm paper surfaces, deep ink typography, and orange signals turn risk into legible next steps.
Probability: 0.06

### Theme Name: Control Room
Very Brief Intro: A dark telemetry workspace with dense status data and high-contrast system signals. It would foreground always-on monitoring for infrastructure-heavy teams.
Probability: 0.03

### Theme Name: Quiet Machine
Very Brief Intro: A pale, low-cognitive-load safety workspace with soft blue-gray surfaces. It would make trust and privacy feel welcoming for early-stage product teams.
Probability: 0.08

## Chosen approach: Field Manual

### Design Movement
Contemporary editorial brutalism blended with field-guide information design. The console should feel like a working safety instrument: structured, tactile, and unambiguous rather than decorative.

### Core Principles
1. Make every moderation signal legible, contextual, and actionable.
2. Make fallback states explicit so the operator understands whether a value is live, simulated, stale, or unavailable.
3. Use editorial rhythm and a persistent operator index rather than a generic centered SaaS dashboard.
4. Treat privacy and recoverability as visible product features.

### Color Philosophy
A warm mineral canvas and deep ink foundation create a calm, document-like environment that avoids alarm fatigue. Signal Orange is reserved for attention and direct action, moss green verifies safe or ready states, and blue-gray carries neutral infrastructure detail.

### Layout Paradigm
A persistent left rail serves as the operator index. The main canvas is an asymmetrical series of decision bands: a narrative header anchors the left, systems context appears on the right, and split cards reveal state, confidence, provenance, and next action without collapsing them into one generic grid.

### Signature Elements
The system uses a vertical signal rail beside risk states, compact uppercase field labels, and orange corner marks that recall annotations in a field manual.

### Interaction Philosophy
Interactions answer “what happened?” immediately. Controls use direct verbs; each simulation makes its source and confidence visible; errors preserve the operator’s choices and offer a focused recovery action.

### Animation
Use 160–220ms snappy transitions for state changes, only run a scan-line sweep while the sandbox is classifying, and gently stagger telemetry rows. Respect reduced motion and never animate data in ways that suggest false precision.

### Typography System
Space Grotesk sets compact, sentence-case headings with strong hierarchy. IBM Plex Mono carries metrics, controls, field labels, code, and source metadata. Long-form explanatory copy remains at 15–17px for readability.

### Brand Essence
SafeScan is the privacy-first moderation layer for teams shipping UGC, built for developers who need a clear, explainable decision before a risky image reaches a user. Personality: **measured, sharp, accountable**.

### Brand Voice
Headlines are plainspoken and confident. Calls to action use concrete verbs; microcopy names boundaries, sources, and limitations rather than offering empty reassurance. Example lines: “Know what crossed the line.” and “Run a sample without sending us a file.”

### Wordmark & Logo
The mark is a compact “S” inferred from two offset inspection brackets and a diagonal scan line. It signals a scan window and a safe boundary without relying on generated typography.

### Signature Brand Color
Signal Orange: `#E86A33` — warm, visible, and distinct from generic developer-tool blue.

## Style Decisions

- The SafeScan logo uses a compact inspection-bracket field with a diagonal scan line; the wordmark supports this mark rather than carrying the identity alone.
- Signal Orange `#E86A33` is functional: primary actions, risk rails, annotation corners, scan marks, and important thresholds only.
- Each major surface makes at least one field-manual concept visible: source, confidence, fallback state, retention boundary, or recovery path.
